# 14 — CLAUDE CODE MASTER INSTRUCTION

## Role

You are implementing the canonical visual system for a React Native + Expo + TypeScript wellness application.

## Source of truth order

1. `00_VISUAL_SYSTEM_CANONICAL.md`
2. `01_VISUAL_DIRECTION.md`
3. `02_COLOR_AND_GRADIENT_TOKENS.md`
4. `03_TYPOGRAPHY_SYSTEM.md`
5. `04_SURFACE_GLASS_GLOW_SYSTEM.md`
6. `05_ICON_ZODIAC_PLANET_GLYPH_SYSTEM.md`
7. `06_BOTANICAL_AND_CELESTIAL_ART_DIRECTION.md`
8. `07_COMPONENT_LIBRARY_CONTRACT.md`
9. `08_SCREEN_COMPOSITION_CONTRACTS.md`
10. `09_MOTION_HAPTICS_LIVING_WORLD.md`
11. `10_ASSET_PIPELINE_AND_NAMING.md`
12. `11_ACCESSIBILITY_AND_PERFORMANCE_BUDGET.md`
13. `12_VISUAL_QA_ACCEPTANCE_CHECKLIST.md`
14. `13_IMPLEMENTATION_PHASE_PLAN.md`

If documents conflict, earlier documents have precedence.

## Non-negotiable product identity

The application must not look like:

- a generic pastel wellness dashboard,
- a children’s fairy notebook,
- a dark witchcraft app,
- a collection of uniformly lilac cards,
- a flat utility dashboard,
- a neon astrology product.

It must feel like:

- a living botanical and celestial editorial system,
- scientifically grounded,
- visually varied,
- softly luminous,
- mature,
- atmospheric,
- adaptive to time,
- accessible,
- performant.

## Mandatory implementation rules

1. Do not redesign business logic unless required.
2. Preserve existing validated Home B1–B6 behavior.
3. Create tokens and primitives before screen refactors.
4. Do not hard-code colors, typography, radii, shadows or glyphs in screens.
5. Use Fraunces + Inter only.
6. Use custom SVG astrology glyphs.
7. Plant cards show common and scientific names.
8. Botanical visuals must not be recolored into a universal brand palette.
9. Limit real blur to two surfaces per screen.
10. Support `adaptive` and `fixedDay` atmosphere modes.
11. Support Reduce Motion and Reduce Transparency.
12. Build loading, empty, error and offline states.
13. Do not use random internet assets.
14. Do not add new dependencies without explaining need and cost.
15. Run typecheck, lint and relevant tests after each phase.

## Execution protocol

For each phase:

1. Audit current files.
2. State which files will change.
3. Implement minimal coherent slice.
4. Run validation.
5. Report:
   - changed files,
   - decisions applied,
   - tests,
   - remaining risks.
6. Commit only after user approval when approval is required by workflow.

## Visual acceptance

Before marking a screen complete, run `12_VISUAL_QA_ACCEPTANCE_CHECKLIST.md`.

## Prohibited shortcuts

- One giant reskin
- Replacing all cards with glass
- Using generated mockup text as production copy
- Using Unicode zodiac symbols as final visual assets
- Hiding scientific names
- Using placeholder botanical art as verified production art
- Skipping Android fallback
- Ignoring accessibility because design is “visual”
- Adding sparkle decorations to compensate for weak hierarchy

## First task

Start with Phase 0 audit from `13_IMPLEMENTATION_PHASE_PLAN.md`.

Produce:

- current token inventory,
- current component inventory,
- duplicated styles,
- Home B1–B6 preservation map,
- asset gaps,
- proposed file migration plan,
- risks.

Do not begin broad visual refactoring before the audit is complete.
